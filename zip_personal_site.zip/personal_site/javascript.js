// Simple script for a dialogue box
alert("This is a beta for my future website portfolio.");